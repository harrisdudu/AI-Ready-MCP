"""配置文件"""
import os

class Config:
    # 模型配置
    # 生成模式，即调用为Chat还是Batch
    MODE = "Chat" 

    if MODE == "Chat":
    # Chat 模式的模型配置
        MODEL_NAME = ""
        MAX_WORKERS = 100
        EVALUATE_MODEL_NAME = ""
        EVALUATE_MAX_WORKERS = 50
    elif MODE == "Batch":
    # Batch 模式的模型配置
        
        MODEL_NAME = ""
        EVALUATE_MODEL_NAME = ""
        MAX_WORKERS = 1000
        EVALUATE_MAX_WORKERS = 1000


    ARK_API_KEY = ""
    
    # 路径配置
    EMBEDDING_MODEL_PATH = "/home/yehongxing/workspace/shi/QA_Generate/bge-m3"
    

    # 每个片段重复生成QA的次数
    MAX_TRY = 2
    
    # 输入输出目录
    INPUT_DIRS = [
        # "/home/yehongxing/workspace/shi/处室_筛选后/评测-指挥中心",
        # "/home/yehongxing/workspace/shi/处室_筛选后/评测-作战训练",
        "/home/yehongxing/workspace/shi/应急管理部下发标准/test"
        ]
    OUTPUT_DIR = "/home/yehongxing/workspace/shi/应急管理部下发标准"