重点关注：桶的名称
s3_util.py  //基础版本 该脚本可以测试单个文件下载以及单个文件夹（PID）下载

download_fire_corpus_origin_single.py  //根据s3_path列表下载数据 BUCKET_NAME = "corpus-origin"

download_fire_corpus_prod_single.py    //根据CID列表下载数据   BUCKET_NAME = "corpus-prod"